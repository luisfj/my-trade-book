@extends('layouts.app')

@section('content')
    <h1 class="text-active">Importar Operações</h1>
    <hr class="bg-warning">

    <importacao-de-arquivo></importacao-de-arquivo>

        <div class="mb-5"></div>
@endsection
